
<?php /**PATH D:\xamp\htdocs\Project\resources\views/register.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    learn one setion section
<?php $__env->stopSection(); ?>
<?php echo $__env->make('learn.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Project\resources\views/learn/learn1.blade.php ENDPATH**/ ?>
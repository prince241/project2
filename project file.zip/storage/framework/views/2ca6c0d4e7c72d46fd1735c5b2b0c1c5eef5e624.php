
<?php $__env->startSection('content'); ?>

    <section id="basic-datatable" class="filter-section">

        <div class="row">
            <div class="col-lg-12 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Products</h4>
                        
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <!-- Table with outer spacing -->
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Sno.</th>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Price</th>
                                            <th>Size</th>
                                            <th>Image</th>
                                        </tr>
                                    </thead>
                                    <tbody class="js-data-list">
                                        <?php if($products->count() > 0): ?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($products->firstItem() + $keys); ?></th>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->description); ?></td>
                                            <td><?php echo e($product->price); ?></td>
                                            <td><?php echo e($product->size); ?></td>
                                            <td><img src="<?php echo e('/images/'.$product->image); ?>"  width="100"></td>
                                          
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                         <td colspan="11" class="pagination-table">
                                            <div class="text-center mt-1">
                                                <?php echo e($products->links('pagination')); ?>

                                            </div>
                                        </td>
                                        <?php else: ?>
                                        <td colspan="11">
                                            <div class="alert alert-danger">Result not found !</div>
                                        </td>    
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Project\resources\views/admin/products/index.blade.php ENDPATH**/ ?>
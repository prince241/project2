
<?php $__env->startSection('content'); ?>
    test2
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Project\resources\views/admin/test2.blade.php ENDPATH**/ ?>
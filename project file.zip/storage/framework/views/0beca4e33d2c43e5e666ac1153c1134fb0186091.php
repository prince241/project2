<a href="<?php echo e(route('logout')); ?>">logout</a>
<h1> THANKU </h1>
<?php /**PATH D:\xamp\htdocs\Project\resources\views/home.blade.php ENDPATH**/ ?>
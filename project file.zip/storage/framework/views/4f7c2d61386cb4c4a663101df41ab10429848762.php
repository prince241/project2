<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <div class="card ecommerce-card">
            <div class="card ecommerce-card">
                <div class="card-content">
                   
    
                    <div class="item-img text-center">
                        <img class="img-fluid" src="<?php echo e('/images/'.$product->image); ?>" alt="img-placeholder">
                    </div>
                    <div class="card-body">
                        <div class="item-wrapper">
                            <div class="item-rating">
                                <div class="badge badge-primary badge-md">
                                    <span>4</span> <i class="feather icon-star"></i>
                                </div>
                            </div>
                            <div>
                                <h6 class="item-price">
                                    <?php echo e($product->price); ?>

                                </h6>
                            </div>
                        </div>
                        <div>
                            <p class="item-description">
                               <?php echo e($product->description); ?>

                            </p>
                        </div>
                        <div>
                            <p class="item-size">
                               <?php echo e($product->size); ?>

                            </p>
                        </div>
                        <div>
                            <p class="item-name">
                               <?php echo e($product->name); ?>

                            </p>
                        </div>
                        <div class="wishlist <?php echo e(in_array($product->id, Auth::user()->wishLists->pluck('product_id')->toArray()) ? 'added' : ''); ?>" onclick="addWishList(this, <?php echo e($product->id); ?>)">
                            <i class="fa mr-25 <?php echo e(in_array($product->id, Auth::user()->wishLists->pluck('product_id')->toArray()) ? 'fa-heart' : 'fa-heart-o'); ?>"></i> Wishlist
                            
                        </div>
                        <div class=""wishlist <?php echo e(in_array($product->id, Auth::user()->wishLists->pluck('product_id')->toArray()) ? 'added' : ''); ?>" onclick="addWishList(this, <?php echo e($product->id); ?>)"">
                            <i class="feather icon-shopping-cart mr-25"></i> <span class="add-to-cart">Add to cart</span>
                             <a href="<?php echo e(route('checklist.checkout')); ?>" class="view-in-cart d-none">View In Cart</a>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xamp\htdocs\Project\resources\views/users/product_list.blade.php ENDPATH**/ ?>
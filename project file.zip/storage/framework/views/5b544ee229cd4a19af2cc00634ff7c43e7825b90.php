<?php if($paginator->lastPage() > 1): ?>
<section id="ecommerce-pagination">
    <div class="row">
        <div class="col-sm-12">
            <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-center mt-2">
                    <li class="page-item prev-item"><a class="page-link" href="<?php echo e($paginator->url(1)); ?>">
                            <i class="feather icon-chevron-left"></i>
                        </a></li>
                    <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
                    <li class="page-item<?php echo e(($paginator->currentPage() == $i) ? ' active' : ''); ?>"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a></li>
                    <?php endfor; ?>
                    <li class="page-item next-item"><a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>">
                            <i class="feather icon-chevron-right"></i>
                        </a></li>
                </ul>
            </nav>
        </div>
    </div>
</section>
<?php endif; ?><?php /**PATH D:\xamp\htdocs\Project\resources\views/pagination.blade.php ENDPATH**/ ?>
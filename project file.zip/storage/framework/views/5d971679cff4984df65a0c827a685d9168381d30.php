<?php if(isset($errors) && count($errors)): ?>
                <div class="alert alert-danger">
                    <span class="closebtn float-right" onclick="this.parentElement.style.display='none';">&times;</span>
                    <b>Sorry, but there was an error:</b>
                    <ul class='m-0'>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <span class="closebtn float-right" onclick="this.parentElement.style.display='none';">&times;</span>
                    <b>Success:</b>
                    <?php if(is_array(session('success'))): ?>
                    <ul class='m-0'>
                        <?php $__currentLoopData = session('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($message); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                    <?php echo e(session('success')); ?>

                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if(session('flash')): ?>
            <div class="alert alert-<?php echo e(session('level')); ?> alert-flash col-md-4"
                role="alert" id="alert_box">
            <span class="closebtn float-right" onclick="this.parentElement.style.display='none';">&times;</span>
                    <strong><?php echo e((session('level')=='success')?'Success':'Error'); ?>!</strong>
                    <?php echo e(session('flash')); ?>

                </div>
            <?php endif; ?>








<?php /**PATH D:\xamp\htdocs\Project\resources\views/users/layouts/flash.blade.php ENDPATH**/ ?>
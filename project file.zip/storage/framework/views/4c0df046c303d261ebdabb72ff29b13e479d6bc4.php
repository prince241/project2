
<?php $__env->startSection('content'); ?>
<div class="container h-100">
    <div class="row h-100">
        <div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
            <div class="d-table-cell align-middle">

                <div class="text-center mt-4">
                    <h1 class="h2">Reset password</h1>
                    <p class="lead">
                        Enter your email to reset your password.
                    </p>
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <span class="closebtn float-right" onclick="this.parentElement.style.display='none';">&times;</span>
                        <b>password sent successfully</b>
                        <?php if(is_array(session('success'))): ?>
                        <ul class='m-0'>
                            <?php $__currentLoopData = session('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                        <?php echo e(session('success')); ?>

                        <?php endif; ?>
                        <?php endif; ?>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="m-sm-4">
                            <form action= <?php echo e(route('password.reset')); ?> method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input class="form-control form-control-lg" type="email" name="email" placeholder="Enter your email">
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <i style="color: red; font-size:small"><?php echo e($message); ?></i>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="text-center mt-3">
                                    
                                     <button type="submit" class="btn btn-lg btn-primary">Reset password</button> 
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Project\resources\views/password/reset.blade.php ENDPATH**/ ?>
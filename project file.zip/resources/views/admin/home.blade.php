@extends('admin.layout.app')
@section('content')
    <div class="card">
        <div class="card-body">
            <h4 class="card-header">Admin home</h4>
        </div>
    </div>
@endsection
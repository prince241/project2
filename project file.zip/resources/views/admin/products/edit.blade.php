@extends('admin.layout.app')
@section('content')
    form to update single product
@endsection
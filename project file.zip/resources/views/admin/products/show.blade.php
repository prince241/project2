@extends('admin.layout.app')
@section('content')
    show singlee product details
@endsection